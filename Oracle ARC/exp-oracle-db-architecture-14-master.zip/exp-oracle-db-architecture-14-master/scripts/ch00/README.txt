The ch00 folder contains scripts used throughout the book.

For exampe:
* creeoda.sql creates the EODA user used in the examples and grants it required privileges.
* login.sql sets the SQL prompt.
* big_table.sql creates the BIG_TABLE table.
* crescott.sql creates the SCOTT schema (if you don't already have that schema).
* tk.sql runs tkprof on a trace file and opens the trace file for editing. 

And so on.
