conn / as sysdba
@?/rdbms/admin/utlsampl.sql
