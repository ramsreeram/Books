-- Tip, consider using dos2unix to remove unwanted characters

host dos2unix /tmp/load.csv
