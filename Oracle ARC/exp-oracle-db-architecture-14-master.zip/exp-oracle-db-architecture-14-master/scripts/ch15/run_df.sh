#!/bin/bash
/bin/df -Pl
