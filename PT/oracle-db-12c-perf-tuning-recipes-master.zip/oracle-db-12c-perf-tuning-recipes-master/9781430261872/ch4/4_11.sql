SELECT min(sample_time) FROM dba_hist_active_sess_history;

