SELECT DISTINCT wait_class FROM dba_hist_event_name order by 1;

