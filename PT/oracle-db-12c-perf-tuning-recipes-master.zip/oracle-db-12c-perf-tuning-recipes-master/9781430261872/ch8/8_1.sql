describe employees

SELECT last_name, first_name
FROM employees;

SELECT *
FROM employees;

SELECT last_name || ', ' || first_name AS "Employee Name"
FROM employees;

