SELECT /*+ full(emp) */ * FROM emp;

